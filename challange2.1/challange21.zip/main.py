class BankAccount:
    def __init__(self, account_number, account_holder_name, initial_balance=0):
        self.__account_number = account_number
        self.__account_holder_name = account_holder_name
        self.__account_balance = initial_balance

    def deposit(self, amount):
        self.__account_balance += amount

    def withdraw(self, amount):
        if amount > self.__account_balance:
            print("Insufficient funds.")
        else:
            self.__account_balance -= amount

    def display_balance(self):
        return self.__account_balance


# Creating an instance of the bank account class
account = BankAccount(account_number="123456789",account_holder_name="hari prabu",initial_balance=5000.0)
#test deposit and withdrawal functionality
account.display_balance()
account.deposit(500.0)
account.withdraw(200.0)
account.display_balance()

